---
layout: homepage
---

## About Me

<p>I received my B.Eng. degree in Automation in 2019 and Ph.D. degree in Cyberspace Security in 2024 from the <a href="https://en.ustc.edu.cn/">University of Science and Technology of China (USTC)</a>, under the supervision of Prof. Yan Chen. From July 2024 to October 2026, I served as a postdoctoral researcher at USTC. I am currently an Assistant Professor in the Department of Informatics and Communication Engineering at Xiamen Univeristy.</p><p>My research interests include WiFi Localization, Signal Processing, and RF Security.</p>

## Selected Publications

{% assign selected_pubs = site.data.publications.main | where: "selected", true %}
{% include yang-publications.html items=selected_pubs %}

<details>
<summary style="cursor:pointer;color:#043361;">Other publications</summary>
{% assign other_pubs = site.data.publications.main | where: "selected", false %}
{% include yang-publications.html items=other_pubs %}
</details>

## Academic Services

<p><strong>Journal reviewer:</strong> IEEE JSAC, TMC, TWC, TAES, TNSE, TCCN, TSIPN, TVT, IoTJ, IoTM, 中国科学: 信息科学, 雷达学报.</p>
