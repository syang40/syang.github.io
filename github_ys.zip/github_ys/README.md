# 杨帅个人学术主页｜Minimal Light

本项目使用原版 Minimal Light Jekyll 远程主题（https://github.com/yaoyao-liu/minimal-light）。无需复制或下载主题自身的样式文件。部署时由 GitHub Pages 获取主题。另提供独立 HTML 离线预览（不属于部署包），外观接近原主题，正式部署可能略有差异。

## 首次部署
1. 登录 GitHub，打开 https://github.com/new 创建 **Public** 仓库，名称必须为 `你的GitHub用户名.github.io`（用户名必须和账户一致）。可以初始化 README。
2. 解压本 ZIP。进入仓库 → Add file → Upload files。将 ZIP 内部的 `index.md`、`_config.yml`、`README.md`、`_data`、`_includes`、`assets` 上传到仓库根目录（不要将整个外层文件夹上传）。提交 Commit changes。
3. 打开 Settings → Pages → Build and deployment，Source 选择 Deploy from a branch；Branch 选择 `main`，目录 `/(root)`，Save。若默认分支名不是 main，选择实际分支。
4. 等待 Actions 中 Pages 构建成功，Settings → Pages 会显示真实公网地址。通常是 `https://你的GitHub用户名.github.io/`。若构建失败，查看 Actions 日志。

## 修改资料（直接在 GitHub 网页上操作）
- `_config.yml`：标题、正式职称（position）、单位（affiliation）、邮箱、学术链接、头像文件路径。填写新单位与职称时替换现有 position，并将 affiliation 的 null 改成正式英文单位。`canonical` 可改为实际网站网址。只有确认的账号链接才填入 google_scholar / github_link 等字段。
- `index.md`：简介、研究方向、动态、项目、荣誉、学术服务。标题用 `##`；正文 HTML 中 `<li>新内容</li>` 是一个条目。维护时不要删除顶部的三行 Jekyll front matter、论文循环与 include 标签。
- `_data/publications.yml`：论文标题、作者、刊会、检索链接、备注；`selected: true` 在代表作显示，false 在折叠的 Other publications 中显示。新增论文复制一条记录并替换字段；保持缩进；作者中 `<strong>Shuai Yang</strong>` 为加粗。可添加真实 `pdf`、`code`、`page` 字段以显示链接。search 为 Google Scholar 标题检索链接，不是 DOI。
- `assets/img/avatar.jpg`：个人照片，换图时上传同名 JPG 或更新 `_config.yml` 中 avatar 路径。
- `_includes/yang-publications.html`：论文列表样式，一般不需要更改。
- 每次修改：打开文件 → 铅笔 Edit this file → Commit changes → 查看 Actions/Pages；构建成功后打开真实网站刷新。

## 发布前核对
- 简历仍写 USTC 博士后，未确认新入职单位、职称与新邮箱。页面没有擅自填写厦门大学或任何具体教师职称。请自行确认后更新 `_config.yml` 与 About Me。
- 论文信息及项目数字依照提交的简历；出版年份、卷期、ESI 状态、项目公开许可需本人核对。未包含在投论文、手机号、出生年月、籍贯、办公地址、原始简历、军工相关项目和项目经费。没有编造 PDF / DOI / 学术账号链接。
- 项目描述、荣誉和照片均须本人确认可公开。

主题：Minimal Light，Yaoyao Liu；原项目许可和说明见 https://github.com/yaoyao-liu/minimal-light 。
