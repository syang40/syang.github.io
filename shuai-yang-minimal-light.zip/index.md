---
layout: homepage
---

## About Me

<p>I received my B.Eng. degree in Automation in 2019 and Ph.D. degree in Cyberspace Security in 2024 from the <a href="https://en.ustc.edu.cn/">University of Science and Technology of China (USTC)</a>, under the supervision of Prof. Yan Chen and Prof. Qibin Sun (IEEE Fellow). I began postdoctoral research at USTC in August 2024.</p><p>My research focuses on wireless sensing and security, with an emphasis on practical WiFi indoor localization, integrated sensing and communication (ISAC), and robust radar sensing in complex environments.</p>

## Research Interests

<ul><li><strong>Wireless Sensing and Localization:</strong> WiFi CSI, multi-AP cooperative localization, robust indoor tracking</li><li><strong>Integrated Sensing and Communication (ISAC):</strong> large-scale commercial WiFi sensing systems</li><li><strong>Wireless Security and Radar Sensing:</strong> interference mitigation, automotive radar, robust RF sensing</li></ul>

## News

<ul><li><strong>[2025]</strong> Our large-scale commercial WiFi ISAC system received a Silver Medal at the 50th International Exhibition of Inventions Geneva.</li><li><strong>[2025]</strong> Our team ranked 4th in the Global Wireless Sensing Competition at ACM MobiCom 2025 (305 participating teams); I served as team leader.</li><li><strong>[2024]</strong> Received the Outstanding Doctoral Graduate award from USTC.</li></ul>

## Selected Publications

{% assign selected_pubs = site.data.publications.main | where: "selected", true %}
{% include yang-publications.html items=selected_pubs %}

<details>
<summary style="cursor:pointer;color:#043361;">Other publications</summary>
{% assign other_pubs = site.data.publications.main | where: "selected", false %}
{% include yang-publications.html items=other_pubs %}
</details>

## Research Projects

<ul><li><strong>Sub-meter WiFi Indoor Localization for Smart Campuses</strong> — Principal Investigator, Nationally Funded Postdoctoral Research Program.</li><li><strong>Large-Scale Commercial WiFi ISAC for Smart Campuses</strong> — Core contributor. The platform comprises approximately 3,700 commercial WiFi access points, covers approximately 320,000 m², supports over 10,000 devices, and has collected more than 20 billion CSI records (figures from the CV).</li><li><strong>FTTR-WiFi Integrated Sensing and Communication</strong> — Technical Lead, Huawei collaborative project.</li><li><strong>Interference Mitigation for Automotive Radar</strong> — Core contributor, Huawei–USTC joint innovation project.</li></ul>

## Honors & Awards

<ul><li>Silver Medal, 50th International Exhibition of Inventions Geneva, 2025.</li><li>4th Place, Global Wireless Sensing Competition @ ACM MobiCom 2025 (Team Leader).</li><li>Outstanding Doctoral Graduate, USTC, 2024.</li><li>First-Class Academic Scholarship, USTC, 2019–2024.</li><li>CETC Scholarship, 2018.</li><li>National Scholarship (Bronze Award), 2016.</li></ul>

## Academic Services

<p><strong>Journal reviewer:</strong> IEEE JSAC, TMC, TWC, TAES, TNSE, TCCN, TSIPN, TVT, IoTJ, IoTM; Science China Information Sciences; Journal of Radars.</p><p><strong>Conference reviewer:</strong> IEEE ICASSP and IJCNN.</p>

